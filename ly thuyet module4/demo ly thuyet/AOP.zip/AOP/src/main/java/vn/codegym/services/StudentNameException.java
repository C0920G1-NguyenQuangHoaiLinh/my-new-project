package vn.codegym.services;

public class StudentNameException extends Exception {
}
