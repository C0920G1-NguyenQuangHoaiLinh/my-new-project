package vn.codegym.validation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AOPApplicationTests {

    @Test
    void contextLoads() {
    }

}
